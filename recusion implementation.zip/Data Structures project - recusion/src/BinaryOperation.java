public class BinaryOperation extends Expression {
    Expression left, right;
    String operator;

    public BinaryOperation(String operator, Expression left, Expression right) {
        this.operator = operator;
        this.left = left;
        this.right = right;
    }

    @Override
    public Expression differentiate(String variable) {
        // Your switch case and logic here...
    }

    @Override
    public double evaluate(Map<String, Double> varValues) {
        // Evaluation logic...
    }
}
