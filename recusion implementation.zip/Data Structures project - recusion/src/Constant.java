public class Constant extends Expression {
    double value;

    public Constant(double value) {
        this.value = value;
    }

    @Override
    public Expression differentiate(String variable) {
        return new Constant(0);
    }

    @Override
    public double evaluate(Map<String, Double> varValues) {
        return value;
    }
}
