import java.util.Map;

public abstract class Expression {
    abstract Expression differentiate(String variable);
    abstract double evaluate(Map<String, Double> varValues);
}
