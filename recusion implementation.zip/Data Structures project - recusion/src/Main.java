import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Example expression: (5 * (x * y))
        Expression expr = new BinaryOperation("*",
                new Constant(5),
                new BinaryOperation("*",
                        new Variable("x"),
                        new Variable("y")));

        // Differentiate with respect to 'x'
        Expression diffExpr = expr.differentiate("x");

        // Prepare variable values for evaluation
        Map<String, Double> varValues = new HashMap<>();
        varValues.put("x", 2.0);
        varValues.put("y", 6.0);

        // Evaluate the differentiated expression
        double result = diffExpr.evaluate(varValues);
        System.out.println("Result: " + result);
    }
}