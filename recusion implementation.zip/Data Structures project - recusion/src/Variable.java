public class Variable extends Expression {
    String name;

    public Variable(String name) {
        this.name = name;
    }

    @Override
    public Expression differentiate(String variable) {
        return variable.equals(this.name) ? new Constant(1) : new Constant(0);
    }

    @Override
    public double evaluate(Map<String, Double> varValues) {
        return varValues.getOrDefault(name, 0.0);
    }
}